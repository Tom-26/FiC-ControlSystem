package com.example.demo.service;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.nio.file.*;

@Service
public class FileStorageService {

    private final Path uploadsDir;
    private final Path tempDir;

    public FileStorageService(@Value("${file.upload-dir}") String uploadDir) {
        Path rootLocation = Paths.get(uploadDir).toAbsolutePath().normalize();

        this.uploadsDir = rootLocation.resolve("uploads");
        this.tempDir = rootLocation.resolve("temp");

        try {
            Files.createDirectories(this.uploadsDir);
            Files.createDirectories(this.tempDir);
        } catch (Exception ex) {
            throw new RuntimeException("Не удалось создать директории для хранения файлов.", ex);
        }
    }

    // Сохранение основного файла (для регистрации)
    public String storeFile(MultipartFile file) {
        // Нормализация имени файла
        String fileName = StringUtils.cleanPath(file.getOriginalFilename());

        try {
            // Проверка на наличие опасных символов
            if (fileName.contains("..")) {
                throw new RuntimeException("Извините! Имя файла содержит недопустимые символы " + fileName);
            }

            // Копирование файла в целевую директорию
            Path targetLocation = this.uploadsDir.resolve(fileName);
            Files.copy(file.getInputStream(), targetLocation, StandardCopyOption.REPLACE_EXISTING);

            return targetLocation.toString(); // Возвращаем полный путь к файлу
        } catch (IOException ex) {
            throw new RuntimeException("Не удалось сохранить файл " + fileName + ". Пожалуйста, попробуйте еще раз!", ex);
        }
    }

    // Сохранение временного файла (для распознавания)
    public String storeFileTemp(MultipartFile file, String fileName) {
        try {
            Path targetLocation = this.tempDir.resolve(fileName);
            Files.copy(file.getInputStream(), targetLocation, StandardCopyOption.REPLACE_EXISTING);
            return targetLocation.toString();
        } catch (IOException ex) {
            throw new RuntimeException("Не удалось сохранить временный файл " + fileName + ". Пожалуйста, попробуйте еще раз!", ex);
        }
    }

    // Удаление файла
    public void deleteFile(String filePath) {
        try {
            Path path = Paths.get(filePath);
            Files.deleteIfExists(path);
        } catch (IOException ex) {
            // Логирование предупреждения (реализуй логирование по необходимости)
        }
    }
}