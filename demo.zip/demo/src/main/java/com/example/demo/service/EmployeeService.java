package com.example.demo.service;

import com.example.demo.exception.ResourceNotFoundException;
import com.example.demo.models.Photo;
import com.example.demo.repository.EmployeeRepository;
import com.example.demo.repository.PhotoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.io.IOUtils;
import org.bytedeco.opencv.opencv_core.*;
import org.bytedeco.opencv.global.opencv_imgcodecs;
import org.bytedeco.opencv.global.opencv_core;
import org.bytedeco.opencv.global.opencv_imgproc;
import org.bytedeco.opencv.global.opencv_objdetect;
import org.bytedeco.opencv.opencv_objdetect.CascadeClassifier;

@Service
public class EmployeeService {

    private final EmployeeRepository employeeRepository;
    private final PhotoRepository photoRepository;
    private final FileStorageService fileStorageService;
    private final CascadeClassifier faceDetector;

    @Autowired
    public EmployeeService(EmployeeRepository employeeRepository, PhotoRepository photoRepository, FileStorageService fileStorageService) {
        this.employeeRepository = employeeRepository;
        this.photoRepository = photoRepository;
        this.fileStorageService = fileStorageService;

        // Загрузка классификатора из ресурсов
        try {
            InputStream is = getClass().getResourceAsStream("/haarcascade_frontalface_alt.xml");
            if (is == null) {
                throw new RuntimeException("Файл классификатора не найден в ресурсах");
            }
            byte[] classifierData = IOUtils.toByteArray(is);
            faceDetector = new CascadeClassifier(new BytePointer(classifierData));

            if (faceDetector.empty()) {
                throw new RuntimeException("Не удалось загрузить модель для обнаружения лиц");
            }
        } catch (Exception e) {
            throw new RuntimeException("Ошибка при загрузке классификатора", e);
        }
    }
    // Получение всех сотрудников
    public List<Employee> getAllEmployees() {
        return employeeRepository.findAll();
    }

    // Получение сотрудника по ID
    public Employee getEmployeeById(Long id) {
        return employeeRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Сотрудник с ID " + id + " не найден"));
    }

    // Создание нового сотрудника
    public Employee createEmployee(Employee employee) {
        return employeeRepository.save(employee);
    }

    // Обновление существующего сотрудника
    public Employee updateEmployee(Long id, Employee updatedEmployee) {
        Employee existingEmployee = employeeRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Сотрудник с ID " + id + " не найден"));

        existingEmployee.setName(updatedEmployee.getName());
        existingEmployee.setEmail(updatedEmployee.getEmail());
        // Обработка фотографий при необходимости

        return employeeRepository.save(existingEmployee);
    }

    // Удаление сотрудника
    public void deleteEmployee(Long id) {
        Employee existingEmployee = employeeRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Сотрудник с ID " + id + " не найден"));

        employeeRepository.delete(existingEmployee);
    }

    // Регистрация сотрудника с загрузкой 3 фотографий
    public Employee registerEmployee(String name, String email, List<MultipartFile> files) {
        if (files.size() != 3) {
            throw new RuntimeException("Для регистрации необходимо загрузить ровно 3 фотографии");
        }

        Employee employee = new Employee();
        employee.setName(name);
        employee.setEmail(email);

        // Сохранение сотрудника для получения ID
        Employee createdEmployee = employeeRepository.save(employee);

        // Обработка и сохранение фотографий
        List<Photo> photos = new ArrayList<>();
        for (MultipartFile file : files) {
            String filePath = fileStorageService.storeFile(file); // Возвращает полный путь
            Photo photo = new Photo(filePath, createdEmployee);
            photos.add(photo);
        }

        photoRepository.saveAll(photos);
        createdEmployee.setPhotos(photos);
        return employeeRepository.save(createdEmployee);
    }

    // Распознавание сотрудника по загруженной фотографии
    public Employee recognizeEmployee(MultipartFile file) {
        // Сохранение временного файла
        String tempFileName = "temp_" + System.currentTimeMillis() + "_" + file.getOriginalFilename();
        String tempFilePath = fileStorageService.storeFileTemp(file, tempFileName);

        try {
            // Загрузка изображения
            Mat image = opencv_imgcodecs.imread(tempFilePath);

            if (image.empty()) {
                throw new RuntimeException("Не удалось прочитать изображение");
            }

            // Остальной код без изменений, но при загрузке сохраненных изображений используем полный путь

            // Получение всех сотрудников из базы
            List<Employee> employees = employeeRepository.findAll();
            for (Employee employee : employees) {
                List<Photo> photos = employee.getPhotos();
                for (Photo photo : photos) {
                    // Загрузка сохраненной фотографии
                    Mat storedImage = opencv_imgcodecs.imread(photo.getFilePath());

                    if (storedImage.empty()) {
                        continue; // Не удалось прочитать сохраненное изображение
                    }

                    // Остальной код без изменений...

                }
            }

            return null; // Совпадение не найдено

        } finally {
            // Удаление временного файла
            fileStorageService.deleteFile(tempFilePath);
        }
    }
}

//package com.example.demo.service;
//import com.example.demo.exception.ResourceNotFoundException;
//import com.example.demo.models.Employee;
//import com.example.demo.models.Photo;
//import com.example.demo.repository.EmployeeRepository;
//import com.example.demo.repository.PhotoRepository;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.stereotype.Service;
//import org.springframework.web.multipart.MultipartFile;
//
//import java.util.ArrayList;
//import java.util.List;
//
//import org.bytedeco.opencv.opencv_core.*;
//import org.bytedeco.opencv.global.opencv_imgcodecs;
//import org.bytedeco.opencv.global.opencv_core;
//import org.bytedeco.opencv.global.opencv_imgproc;
//import org.bytedeco.opencv.global.opencv_objdetect;
//import org.bytedeco.opencv.opencv_objdetect.CascadeClassifier;
//
//@Service
//public class EmployeeService {
//
//    private final EmployeeRepository employeeRepository;
//    private final PhotoRepository photoRepository;
//    private final FileStorageService fileStorageService;
//    private final CascadeClassifier faceDetector;
//
//    @Autowired
//    public EmployeeService(EmployeeRepository employeeRepository, PhotoRepository photoRepository, FileStorageService fileStorageService) {
//        this.employeeRepository = employeeRepository;
//        this.photoRepository = photoRepository;
//        this.fileStorageService = fileStorageService;
//
//        // Инициализация детектора лиц с использованием предобученной модели
//        String classifierPath = "src/main/resources/haarcascade_frontalface_alt.xml"; // Убедись, что файл существует
//        faceDetector = new CascadeClassifier(classifierPath);
//        if (faceDetector.empty()) {
//            throw new RuntimeException("Не удалось загрузить модель для обнаружения лиц");
//        }
//    }
//
//    // Получение всех сотрудников
//    public List<Employee> getAllEmployees() {
//        return employeeRepository.findAll();
//    }
//
//    // Получение сотрудника по ID
//    public Employee getEmployeeById(Long id) {
//        return employeeRepository.findById(id)
//                .orElseThrow(() -> new ResourceNotFoundException("Сотрудник с ID " + id + " не найден"));
//    }
//
//    // Создание нового сотрудника
//    public Employee createEmployee(Employee employee) {
//        return employeeRepository.save(employee);
//    }
//
//    // Обновление существующего сотрудника
//    public Employee updateEmployee(Long id, Employee updatedEmployee) {
//        Employee existingEmployee = employeeRepository.findById(id)
//                .orElseThrow(() -> new ResourceNotFoundException("Сотрудник с ID " + id + " не найден"));
//
//        existingEmployee.setName(updatedEmployee.getName());
//        existingEmployee.setEmail(updatedEmployee.getEmail());
//        // Обработка фотографий при необходимости
//
//        return employeeRepository.save(existingEmployee);
//    }
//
//    // Удаление сотрудника
//    public void deleteEmployee(Long id) {
//        Employee existingEmployee = employeeRepository.findById(id)
//                .orElseThrow(() -> new ResourceNotFoundException("Сотрудник с ID " + id + " не найден"));
//
//        employeeRepository.delete(existingEmployee);
//    }
//
//    // Регистрация сотрудника с загрузкой 3 фотографий
//    public Employee registerEmployee(String name, String email, List<MultipartFile> files) {
//        if (files.size() != 3) {
//            throw new RuntimeException("Для регистрации необходимо загрузить ровно 3 фотографии");
//        }
//
//        Employee employee = new Employee();
//        employee.setName(name);
//        employee.setEmail(email);
//
//        // Сохранение сотрудника для получения ID
//        Employee createdEmployee = employeeRepository.save(employee);
//
//        // Обработка и сохранение фотографий
//        List<Photo> photos = new ArrayList<>();
//        for (MultipartFile file : files) {
//            String fileName = fileStorageService.storeFile(file);
//            String filePath = "uploads/" + fileName; // Путь к файлу
//            Photo photo = new Photo(filePath, createdEmployee);
//            photos.add(photo);
//        }
//
//        photoRepository.saveAll(photos);
//        createdEmployee.setPhotos(photos);
//        return employeeRepository.save(createdEmployee);
//    }
//
//    // Распознавание сотрудника по загруженной фотографии
//    public Employee recognizeEmployee(MultipartFile file) {
//        // Сохранение временного файла
//        String tempFileName = "temp_" + System.currentTimeMillis() + "_" + file.getOriginalFilename();
//        String tempFilePath = fileStorageService.storeFileTemp(file, tempFileName);
//
//        try {
//            // Загрузка изображения
//            Mat image = opencv_imgcodecs.imread(fileStorageService.getFullPath(tempFilePath));
//
//            if (image.empty()) {
//                throw new RuntimeException("Не удалось прочитать изображение");
//            }
//
//            // Обнаружение лиц
//            MatOfRect faceDetections = new MatOfRect();
//            faceDetector.detectMultiScale(image, faceDetections);
//
//            if (faceDetections.toArray().length == 0) {
//                throw new RuntimeException("Лица не обнаружены на изображении");
//            }
//
//            // Предполагаем, что на изображении одно лицо
//            Rect rect = faceDetections.toArray()[0];
//            Mat face = new Mat(image, rect);
//
//            // Преобразование в оттенки серого
//            Mat grayFace = new Mat();
//            opencv_imgproc.cvtColor(face, grayFace, opencv_imgproc.COLOR_BGR2GRAY);
//
//            // Изменение размера до стандартного
//            Mat resizedFace = new Mat();
//            Size size = new Size(100, 100);
//            opencv_imgproc.resize(grayFace, resizedFace, size);
//
//            // Преобразование в вектор признаков (простой подход)
//            Mat encoding = resizedFace.reshape(1, 1); // 1 строка, N столбцов
//
//            // Нормализация признаков
//            opencv_core.normalize(encoding, encoding, 1.0, 0.0, opencv_core.NORM_L2);
//
//            // Получение всех сотрудников из базы
//            List<Employee> employees = employeeRepository.findAll();
//            for (Employee employee : employees) {
//                List<Photo> photos = employee.getPhotos();
//                for (Photo photo : photos) {
//                    // Загрузка сохраненной фотографии
//                    Mat storedImage = opencv_imgcodecs.imread(fileStorageService.getFullPath(photo.getFilePath()));
//
//                    if (storedImage.empty()) {
//                        continue; // Не удалось прочитать сохраненное изображение
//                    }
//
//                    // Обнаружение лиц на сохраненной фотографии
//                    MatOfRect storedFaceDetections = new MatOfRect();
//                    faceDetector.detectMultiScale(storedImage, storedFaceDetections);
//
//                    if (storedFaceDetections.toArray().length == 0) {
//                        continue; // Лица не обнаружены на сохраненной фотографии
//                    }
//
//                    Rect storedRect = storedFaceDetections.toArray()[0];
//                    Mat storedFace = new Mat(storedImage, storedRect);
//
//                    // Преобразование в оттенки серого
//                    Mat storedGrayFace = new Mat();
//                    opencv_imgproc.cvtColor(storedFace, storedGrayFace, opencv_imgproc.COLOR_BGR2GRAY);
//
//                    // Изменение размера до стандартного
//                    Mat storedResizedFace = new Mat();
//                    opencv_imgproc.resize(storedGrayFace, storedResizedFace, size);
//
//                    // Преобразование в вектор признаков
//                    Mat storedEncoding = storedResizedFace.reshape(1, 1);
//                    opencv_core.normalize(storedEncoding, storedEncoding, 1.0, 0.0, opencv_core.NORM_L2);
//
//                    // Вычисление сходства (dot product)
//                    double similarity = opencv_core.dot(encoding, storedEncoding);
//
//                    // Порог сходства (можно настроить)
//                    if (similarity > 0.6) {
//                        return employee;
//                    }
//                }
//            }
//
//            return null; // Совпадение не найдено
//
//        } finally {
//            // Удаление временного файла
//            fileStorageService.deleteFile(tempFilePath);
//        }
//    }
//}
