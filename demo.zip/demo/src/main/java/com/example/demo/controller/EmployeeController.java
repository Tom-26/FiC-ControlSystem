package com.example.demo.controller;

import com.example.demo.service.EmployeeService;
import com.example.demo.exception.ResourceNotFoundException;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;

@RestController
@RequestMapping("/api/employees")
public class EmployeeController {

    private final EmployeeService employeeService;

    @Autowired
    public EmployeeController(EmployeeService employeeService) {
        this.employeeService = employeeService;
    }

    // Получение всех сотрудников
    @GetMapping
    public ResponseEntity<List<Employee>> getAllEmployees() {
        List<Employee> employees = employeeService.getAllEmployees();
        return new ResponseEntity<>(employees, HttpStatus.OK);
    }

    // Получение сотрудника по ID
    @GetMapping("/{id}")
    public ResponseEntity<Employee> getEmployeeById(@PathVariable Long id) {
        Employee employee = employeeService.getEmployeeById(id);
        return new ResponseEntity<>(employee, HttpStatus.OK);
    }

    // Создание нового сотрудника (без фотографий)
    @PostMapping
    public ResponseEntity<Employee> createEmployee(@Valid @RequestBody Employee employee) {
        Employee createdEmployee = employeeService.createEmployee(employee);
        return new ResponseEntity<>(createdEmployee, HttpStatus.CREATED);
    }

    // Обновление существующего сотрудника
    @PutMapping("/{id}")
    public ResponseEntity<Employee> updateEmployee(@PathVariable Long id, @Valid @RequestBody Employee employee) {
        Employee updatedEmployee = employeeService.updateEmployee(id, employee);
        return new ResponseEntity<>(updatedEmployee, HttpStatus.OK);
    }

    // Удаление сотрудника
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteEmployee(@PathVariable Long id) {
        employeeService.deleteEmployee(id);
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }

    // Регистрация сотрудника с 3 фотографиями
    @PostMapping("/register")
    public ResponseEntity<Employee> registerEmployee(
            @RequestParam("name") String name,
            @RequestParam("email") String email,
            @RequestParam("files") List<MultipartFile> files
    ) {
        Employee registeredEmployee = employeeService.registerEmployee(name, email, files);
        return new ResponseEntity<>(registeredEmployee, HttpStatus.CREATED);
    }

    // Распознавание сотрудника по фотографии
    @PostMapping("/recognize")
    public ResponseEntity<Employee> recognizeEmployee(@RequestParam("file") MultipartFile file) {
        Employee recognizedEmployee = employeeService.recognizeEmployee(file);
        if (recognizedEmployee != null) {
            return new ResponseEntity<>(recognizedEmployee, HttpStatus.OK);
        } else {
            throw new ResourceNotFoundException("Совпадение с сотрудником не найдено");
        }
    }
}
