package com.example.demo.models;

import jakarta.persistence.*;

@Entity
@Table(name = "photos")
public class Photo {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    // Путь к файлу фотографии
    @Column(nullable = false)
    private String filePath;

    // Связь с сотрудником
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "employee_id", nullable = false)
    private Employee employee;

    // Конструкторы

    public Photo() {
    }

    public Photo(String filePath, Employee employee) {
        this.filePath = filePath;
        this.employee = employee;
    }

    // Геттеры и сеттеры

    public Long getId() {
        return id;
    }

    // Обычно сеттер для ID не нужен

    public String getFilePath() {
        return filePath;
    }

    public void setFilePath(String filePath) {
        this.filePath = filePath;
    }

    public Employee getEmployee() {
        return employee;
    }

    public void setEmployee(Employee employee) {
        this.employee = employee;
    }

    // Переопределение методов equals и hashCode

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        Photo photo = (Photo) o;

        if (!id.equals(photo.id)) return false;
        if (!filePath.equals(photo.filePath)) return false;
        return employee.equals(photo.employee);
    }

    @Override
    public int hashCode() {
        int result = id.hashCode();
        result = 31 * result + filePath.hashCode();
        result = 31 * result + employee.hashCode();
        return result;
    }

    // Переопределение метода toString

    @Override
    public String toString() {
        return "Photo{" +
                "id=" + id +
                ", filePath='" + filePath + '\'' +
                '}';
    }
}
